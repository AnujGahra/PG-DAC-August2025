package examples;
import java.util.Arrays;
public class Sorting {
public static void main(String[] args) {
	 int[] arr = {40, 10, 30, 50, 20};
	 		// Sorting array in ascending order using Arrays.sort()
	        Arrays.sort(arr);

	        // Traversing sorted array
	        for (int no : arr)
	        {
	            System.out.print(no + " ");
	        }
	    }
	}


