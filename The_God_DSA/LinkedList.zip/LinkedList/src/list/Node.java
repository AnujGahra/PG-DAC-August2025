/**
 * 
 */
package list;

/**
 * 
 */
public class Node {

	/**
	 * 
	 */
	public int data;
	public Node next;
	public Node() {
		// TODO Auto-generated constructor stub
	}

}
