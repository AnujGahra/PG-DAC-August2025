package list;

public interface LinkedListInterf {
	public void addAtFront(int element);
	public void print();
	public void addAtRear(int element);
	int deleteFirstNode();
	
	

}
